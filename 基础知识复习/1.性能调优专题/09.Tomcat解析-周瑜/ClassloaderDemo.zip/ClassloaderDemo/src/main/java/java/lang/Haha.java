package java.lang;

public class Haha {
}
