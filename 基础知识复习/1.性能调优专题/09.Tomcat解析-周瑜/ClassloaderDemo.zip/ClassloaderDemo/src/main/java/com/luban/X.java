package com.luban;

public class X {
    static {
        System.out.println("123");
    }

    public static void main(String[] args) {

    }
}
