package com.luban;

public class Y {

    public void test(){}

    public static void main(String[] args) {

    }
}
